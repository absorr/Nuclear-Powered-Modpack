package mods.railcraft.api.signals;

/**
 *
 * @author CovertJaguar <http://www.railcraft.info>
 */
public abstract class SignalTools {

    public static IPairEffectRenderer effectManager;
    public static ISignalPacketBuilder packetBuilder;
}
